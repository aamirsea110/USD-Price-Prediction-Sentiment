with open('usddata.csv', 'r') as f:
    d = f.readlines()

with open('usddata2.txt', 'w') as f2:
    while len(d) >= 0:
        f2.write(d.pop())