from statsmodels.tsa.arima_model import ARIMAResults # for loading model
import datetime # for handling datetime

# loading the trained model
model = ARIMAResults.load("model")
# starting date from where the model starts forecasting
origin_date = datetime.date(year=2019, month=10, day=19)

# difference from origin date and the required date
def get_date_difference(d1, d2):
    return abs((d2 - d1).days)

# getting todays date
def get_today_date():
    today = datetime.date.today()
    return today

# getting tomorrows date
def get_tomorrow_date():
    tomorrow = datetime.date.today() + datetime.timedelta(days=1)
    return tomorrow

# getting forecast for given date
def get_forecast(d):
    # calculate difference between given date and origin date to get steps in the future to forecast
    diff = get_date_difference(origin_date, d)
    return model.forecast(steps=diff)[0][-1]

