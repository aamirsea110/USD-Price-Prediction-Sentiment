import predictor # contains functions that interface the trined model
import tkinter as tk # for gui
import calendar # for calendar and datetime functions
from tkcalendar import Calendar, DateEntry # for calendar date picker
import datetime # for datetime functions
from matplotlib import pyplot as plt # for visualizations
import random # for random number generation

# app GUI class
class app:
    def __init__(self, master):
        # making frame in window
        self.frame = tk.Frame(master)
        self.frame.pack()

        # making a label with text
        tk.Label(
            self.frame,
            text="Get prediction of USD price for any day! \n\nJust click on the Calendar to select the date. \n\nYou can also view trends by clicking on Graphs.",
            font=("Arial", 16)
        ).grid(row=0, columnspan=2, padx=10, pady=10)

        # making the calendar button
        tk.Button(self.frame, text="Calendar", command=self.calendar_window, font=("Arial", 12)).grid(
            row=1, columnspan=2, padx=10, pady=10
        )

        # making a frame to contain sentiment stuff
        self.sentiment_frame = tk.Frame(self.frame)
        self.sentiment_frame.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        # making label that says sentiments
        tk.Label(self.sentiment_frame, text="Sentiments", font=("Arial", 12)).grid(row=0, column=0)
        # making a text box for entering sentiments
        self.sentiment_entry = tk.Entry(self.sentiment_frame)
        self.sentiment_entry.grid(row=0, column=1, padx=10)
        self.sentiment_entry.insert(0, "0")
        # making label that says default = 0
        tk.Label(self.sentiment_frame, text="default = 0", font=("Arial", 12)).grid(
            row=0, column=2, padx=10
        )

        # making update button
        self.update_button = tk.Button(
            self.frame, text="Update", command=self.update_output, font=("Arial", 12)
        )
        self.update_button.grid(row=3, columnspan=2, padx=10, pady=10)

        # the current price forecasted
        self.current_price = 0
        # the current date selected
        self.current_date = datetime.date.today()

        # the output label where forecast is shown
        self.output = tk.StringVar()
        self.prediction_label = tk.Label(self.frame, textvariable=self.output, font=("Times", 12))
        self.prediction_label.grid(row=4, columnspan=2, padx=10, pady=10)

        # making graphs button
        tk.Button(self.frame, text="Graphs", command=self.graph_window, font=("Arial", 12)).grid(
            row=5, columnspan=2, padx=10, pady=10
        )
    
    def calendar_window(self):
        # fucntion runs when date is selected
        def print_sel():
            # get selected date
            selected_date = cal.selection_get()
            # set it as current date
            self.current_date = selected_date
            # get forecast at current date
            price = predictor.get_forecast(selected_date)
            try:
                # get sentiments from sentiments text box
                sentiment = int(self.sentiment_entry.get())
            except:
                # if user has entered something other than a number than just set it 0
                sentiment = 0
            # add sentiment to forecast price
            price += (sentiment * random.random())
            # round down
            price = round(price, 2)
            price = str(price)
            # get date in a human readable form
            temp_d = f"{str(selected_date.day)} {str(calendar.month_name[selected_date.month])} {str(selected_date.year)}"
            # text to be written in output
            prediction = f"Prediction: Rs. {price} = $1 on {temp_d}"
            # set current forecast as current price
            self.current_price = price
            # set the prediction to the output
            self.output.set(prediction)

        # create a new window
        top = tk.Toplevel(self.frame)

        # get todays date
        today = datetime.date.today()

        # create a calendar date picker in that window
        cal = Calendar(
            top,
            selectmode="day",
            locale="en_US",
            disabledforeground="red",
            cursor="hand1",
            year=today.year,
            month=today.month,
            day=today.day,
        )
        cal.pack(fill="both", expand=True)

        # make a button to select the date
        tk.Button(top, text="ok", command=print_sel).pack(padx=10, pady=10)

    def update_output(self):
        try:
            # get current value entered in sentiment text box
            sentiment = float(self.sentiment_entry.get())
        except:
            # if value is not numeric than set sentiments as 0
            sentiment = 0
        # get new price with sentiments added
        price = float(self.current_price) + (sentiment * random.random())
        # round down
        price = round(price, 2)
        price = str(price)
        # get date in human readable form
        temp_d = f"{str(self.current_date.day)} {str(calendar.month_name[self.current_date.month])} {str(self.current_date.year)}"
        # make text for output
        prediction = f"Prediction: Rs. {price} = $1 on {temp_d}"
        self.current_price = price
        # set it as output
        self.output.set(prediction)

    # this is the same thing as the calendar_window function it just get the date for the start date
    def graph_calendar_window_date1(self):
        def print_sel():
            # get selected date
            selected_date = cal.selection_get()
            # set it as start date
            self.date1 = selected_date
            # get start date in human readable form
            temp = f"{str(self.date1.day)} {calendar.month_name[self.date1.month]} {str(self.date1.year)}"
            # set the start date
            self.d1.set(temp)
            # close calendar window
            top1.destroy()

        # these same operations that were in calendar_window()
        top1 = tk.Toplevel(self.top)

        today = datetime.date.today()
        mindate = datetime.date(year=2019, month=10, day=19)
        cal = Calendar(
            top1,
            selectmode="day",
            locale="en_US",
            mindate = mindate,
            disabledforeground="red",
            cursor="hand1",
            year=today.year,
            month=today.month,
            day=today.day,
        )
        cal.pack(fill="both", expand=True)
        tk.Button(top1, text="ok", command=print_sel).pack(padx=10, pady=10)
    # this is the same thing as the calendar_window function it just get the date for the end date
    def graph_calendar_window_date2(self):
        def print_sel():
            # same as graph_calendar_window_date1 but for end date
            selected_date = cal.selection_get()
            self.date2 = selected_date
            temp = f"{str(self.date2.day)} {calendar.month_name[self.date2.month]} {str(self.date2.year)}"
            self.d2.set(temp)
            top2.destroy()

        top2 = tk.Toplevel(self.top)

        today = datetime.date.today()
        mindate = self.date1 + datetime.timedelta(days=1)
        cal = Calendar(
            top2,
            selectmode="day",
            locale="en_US",
            mindate = mindate,
            disabledforeground="red",
            cursor="hand1",
            year=today.year,
            month=today.month,
            day=today.day,
        )
        cal.pack(fill="both", expand=True)
        tk.Button(top2, text="ok", command=print_sel).pack(padx=10, pady=10)
    
    def generate_graph(self):
        # get the start and end dates
        d1 = self.date1
        d2 = self.date2
        # get difference of days between them
        diff = (d2 - d1).days
        diff = int(diff)
        # list that will contain values of the x-axis of graph
        x_axis = []
        # populating x-axis list
        for i in range(diff + 1):
            # append it with dates from start date to end date
            x_axis.append(d1)
            d1 = d1 + datetime.timedelta(days=1)
        # list that contains values of forecast corresponding to dates, it will be the y-axis
        y_axis = []
        # populating y-axis list
        for i in range(diff + 1):
            # get forecast for each value in x-axis and store it in y-axis list
            y_axis.append(predictor.get_forecast(x_axis[i]))
        # plot the x and y axis list
        plt.plot(x_axis, y_axis)
        plt.show()

    def graph_window(self):
        # create new window
        self.top = tk.Toplevel(self.frame)
        # initialize start and end date with todays date
        self.date1 = datetime.date.today()
        self.date2 = datetime.date.today()
        
        # make 2 buttons for selecting start and end dates
        tk.Button(self.top, text="Start Date", command=self.graph_calendar_window_date1).grid(row=0, column=0, padx=10, pady=10)
        tk.Button(self.top, text="End Date", command=self.graph_calendar_window_date2).grid(row=0, column=1, padx=10, pady=10)

        # make 2 labels for displaying start and end dates
        self.d1 = tk.StringVar()
        self.d2 = tk.StringVar()
        tk.Label(self.top, textvariable=self.d1).grid(row=1, column=0, padx=10, pady=10)
        tk.Label(self.top, textvariable=self.d2).grid(row=1, column=1, padx=10, pady=10)

        # make button to generate graph from start and end dates
        tk.Button(self.top, text="Generate Graph", command=self.generate_graph).grid(row=2, columnspan=2, padx=10, pady=10)

# initializing tkinter
root = tk.Tk()
# setting title of app
root.title("USD Price Predictor with Sentiments")

# initializing the GUI and attaching it to tkinter
a = app(root)

# the mainloop of the GUI to keep it running
root.mainloop()
