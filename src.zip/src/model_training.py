import pandas as pd # for dataset handling
from matplotlib import pyplot # for visualizations
from pandas.plotting import autocorrelation_plot # for drawing autocorrelation plot
from statsmodels.tsa.arima_model import ARIMA # the arima model
from statsmodels.tsa.arima_model import ARIMAResults # for saving and loading model
from sklearn.metrics import mean_squared_error # for calculating error

# path where the dataset is located
path = "/home/hassan/programming/projects/USD_to_PKR_Predictor_using_Sentiment_Analysis_of_News/dataset/usddatacleaned.csv"
# reading the dataset with pandas and storing it as a dataframe in data variable
data = pd.read_csv(path, sep=",")

# converting the date column in dataframe to datetime format
data["date"] = pd.to_datetime(data["date"])
# making date the index
data.index = data["date"]
# deleting the date column because it was made an index
del data["date"]

# getting values of data in X
X = data.values
# getting size 66% of the data
size = int(len(X) * 0.66)
# seperating data into train and test parts, train part has size length and test is the rest 
train, test = X[0:size], X[size : len(X)]
# creating variable history which contains all values of train
history = [x for x in train]
# creating an empty list called predictions
predictions = list()
# loop where the training happens, it runs for amount of values in test
for t in range(len(test)):
    # giving ARIMA the train values and d, p, q parameters
    model = ARIMA(history, order=(5, 1, 0))
    # fitting the model on the data
    model_fit = model.fit(disp=0)
    # getting forecast from the trained model
    output = model_fit.forecast()
    # storing the forecast to yhat
    yhat = output[0]
    # appending the forecast to predictions
    predictions.append(yhat)
    # adding the t values of test to history to be considered for the next epoch of training
    obs = test[t]
    # appending obs to history
    history.append(obs)
    # metrics of the training, forecasted values and the actual value
    print("predicted=%f, expected=%f" % (yhat, obs))
# calculating error in the testing and predictions
error = mean_squared_error(test, predictions)
# printing error
print("Test MSE: %.3f" % error)
# plotting the results
pyplot.plot(test)
pyplot.plot(predictions, color="red")
pyplot.show()
# saving the trained model
model_fit.save("model")

